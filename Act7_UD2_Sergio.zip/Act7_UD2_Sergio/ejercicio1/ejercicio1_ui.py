# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ejercicio1.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QMainWindow, QMenuBar, QPushButton,
    QSizePolicy, QStatusBar, QVBoxLayout, QWidget)

class Ui_QMainWindow(object):
    def setupUi(self, QMainWindow):
        if not QMainWindow.objectName():
            QMainWindow.setObjectName(u"QMainWindow")
        QMainWindow.resize(800, 600)
        self.centralwidget = QWidget(QMainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setStyleSheet(u"")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.btn4 = QPushButton(self.centralwidget)
        self.btn4.setObjectName(u"btn4")

        self.verticalLayout.addWidget(self.btn4)

        self.btn3 = QPushButton(self.centralwidget)
        self.btn3.setObjectName(u"btn3")

        self.verticalLayout.addWidget(self.btn3)

        self.btn2 = QPushButton(self.centralwidget)
        self.btn2.setObjectName(u"btn2")

        self.verticalLayout.addWidget(self.btn2)

        self.btn1 = QPushButton(self.centralwidget)
        self.btn1.setObjectName(u"btn1")

        self.verticalLayout.addWidget(self.btn1)

        QMainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(QMainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 20))
        QMainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(QMainWindow)
        self.statusbar.setObjectName(u"statusbar")
        QMainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(QMainWindow)

        QMetaObject.connectSlotsByName(QMainWindow)
    # setupUi

    def retranslateUi(self, QMainWindow):
        QMainWindow.setWindowTitle(QCoreApplication.translate("QMainWindow", u"Layout Vertical con Botones", None))
        self.btn4.setText(QCoreApplication.translate("QMainWindow", u"Cuatro", None))
        self.btn3.setText(QCoreApplication.translate("QMainWindow", u"Tres", None))
        self.btn2.setText(QCoreApplication.translate("QMainWindow", u"Dos", None))
        self.btn1.setText(QCoreApplication.translate("QMainWindow", u"Uno", None))
    # retranslateUi

