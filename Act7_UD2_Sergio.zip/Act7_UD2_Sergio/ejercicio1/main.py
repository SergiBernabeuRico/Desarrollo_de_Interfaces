import sys

from PySide6.QtWidgets import QApplication, QMainWindow

# Importamos la clase generada automáticamente desde el archivo .ui.
# Este archivo ejercicio1_ui.py se crea al compilar ejercicio1.ui.
from ejercicio1_ui import Ui_QMainWindow

class VentanaPrincipal(QMainWindow):

    # Este método se ejecuta al crear la ventana.
    def __init__(self):
        super().__init__()
        
        self.ui = Ui_QMainWindow()

        # Cargamos la interfaz dentro de esta ventana.
        self.ui.setupUi(self)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = VentanaPrincipal()
    ventana.show()
    sys.exit(app.exec())