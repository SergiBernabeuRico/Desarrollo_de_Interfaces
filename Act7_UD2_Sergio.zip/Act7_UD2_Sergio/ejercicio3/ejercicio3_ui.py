# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ejercicio3.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QDoubleSpinBox, QFormLayout, QLabel,
    QLineEdit, QMainWindow, QMenuBar, QSizePolicy,
    QSpinBox, QStatusBar, QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(320, 154)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.contenedorFormulario = QWidget(self.centralwidget)
        self.contenedorFormulario.setObjectName(u"contenedorFormulario")
        self.formLayout = QFormLayout(self.contenedorFormulario)
        self.formLayout.setObjectName(u"formLayout")
        self.lblTexto = QLabel(self.contenedorFormulario)
        self.lblTexto.setObjectName(u"lblTexto")

        self.formLayout.setWidget(0, QFormLayout.ItemRole.LabelRole, self.lblTexto)

        self.lineEdit = QLineEdit(self.contenedorFormulario)
        self.lineEdit.setObjectName(u"lineEdit")

        self.formLayout.setWidget(0, QFormLayout.ItemRole.FieldRole, self.lineEdit)

        self.lblEntero = QLabel(self.contenedorFormulario)
        self.lblEntero.setObjectName(u"lblEntero")

        self.formLayout.setWidget(1, QFormLayout.ItemRole.LabelRole, self.lblEntero)

        self.spinBox = QSpinBox(self.contenedorFormulario)
        self.spinBox.setObjectName(u"spinBox")
        self.spinBox.setValue(56)

        self.formLayout.setWidget(1, QFormLayout.ItemRole.FieldRole, self.spinBox)

        self.lblDecimal = QLabel(self.contenedorFormulario)
        self.lblDecimal.setObjectName(u"lblDecimal")

        self.formLayout.setWidget(2, QFormLayout.ItemRole.LabelRole, self.lblDecimal)

        self.doubleDecimal = QDoubleSpinBox(self.contenedorFormulario)
        self.doubleDecimal.setObjectName(u"doubleDecimal")
        self.doubleDecimal.setMaximum(99.989999999999995)
        self.doubleDecimal.setValue(6.550000000000000)

        self.formLayout.setWidget(2, QFormLayout.ItemRole.FieldRole, self.doubleDecimal)


        self.verticalLayout.addWidget(self.contenedorFormulario)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 320, 20))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Layout Formulario", None))
        self.lblTexto.setText(QCoreApplication.translate("MainWindow", u"Texto", None))
        self.lineEdit.setText(QCoreApplication.translate("MainWindow", u"Sergi", None))
        self.lblEntero.setText(QCoreApplication.translate("MainWindow", u"Entero", None))
        self.lblDecimal.setText(QCoreApplication.translate("MainWindow", u"Decimal", None))
    # retranslateUi

