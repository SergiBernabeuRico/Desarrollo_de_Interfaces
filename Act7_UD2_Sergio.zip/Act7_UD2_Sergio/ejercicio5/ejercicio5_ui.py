# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ejercicio5.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGridLayout, QMainWindow, QMenuBar,
    QPushButton, QSizePolicy, QStatusBar, QVBoxLayout,
    QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(368, 166)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.ContenedorGrid = QWidget(self.centralwidget)
        self.ContenedorGrid.setObjectName(u"ContenedorGrid")
        self.widget = QWidget(self.ContenedorGrid)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(1, 13, 340, 83))
        self.gridLayout = QGridLayout(self.widget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(0, 0, 0, 0)
        self.btn00 = QPushButton(self.widget)
        self.btn00.setObjectName(u"btn00")

        self.gridLayout.addWidget(self.btn00, 0, 0, 1, 1)

        self.btn01 = QPushButton(self.widget)
        self.btn01.setObjectName(u"btn01")

        self.gridLayout.addWidget(self.btn01, 0, 1, 1, 1)

        self.btn02 = QPushButton(self.widget)
        self.btn02.setObjectName(u"btn02")

        self.gridLayout.addWidget(self.btn02, 0, 2, 1, 1)

        self.btn03 = QPushButton(self.widget)
        self.btn03.setObjectName(u"btn03")

        self.gridLayout.addWidget(self.btn03, 0, 3, 1, 1)

        self.btn10_13 = QPushButton(self.widget)
        self.btn10_13.setObjectName(u"btn10_13")

        self.gridLayout.addWidget(self.btn10_13, 1, 0, 1, 4)

        self.btn20_21 = QPushButton(self.widget)
        self.btn20_21.setObjectName(u"btn20_21")

        self.gridLayout.addWidget(self.btn20_21, 2, 0, 1, 2)

        self.btn22_23 = QPushButton(self.widget)
        self.btn22_23.setObjectName(u"btn22_23")

        self.gridLayout.addWidget(self.btn22_23, 2, 2, 1, 2)


        self.verticalLayout.addWidget(self.ContenedorGrid)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 368, 20))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Layout Cuardricula", None))
        self.btn00.setText(QCoreApplication.translate("MainWindow", u"0,0", None))
        self.btn01.setText(QCoreApplication.translate("MainWindow", u"0,1", None))
        self.btn02.setText(QCoreApplication.translate("MainWindow", u"0,2", None))
        self.btn03.setText(QCoreApplication.translate("MainWindow", u"0,3", None))
        self.btn10_13.setText(QCoreApplication.translate("MainWindow", u"1, 0-3", None))
        self.btn20_21.setText(QCoreApplication.translate("MainWindow", u"2, 0-2", None))
        self.btn22_23.setText(QCoreApplication.translate("MainWindow", u"2, 2-4", None))
    # retranslateUi

