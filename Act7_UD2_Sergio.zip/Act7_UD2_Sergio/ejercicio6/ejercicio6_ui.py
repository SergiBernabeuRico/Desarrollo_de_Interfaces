# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ejercicio6.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QGroupBox, QMainWindow,
    QMenuBar, QSizePolicy, QStatusBar, QVBoxLayout,
    QWidget)

class Ui_LayoutconCheckBox(object):
    def setupUi(self, LayoutconCheckBox):
        if not LayoutconCheckBox.objectName():
            LayoutconCheckBox.setObjectName(u"LayoutconCheckBox")
        LayoutconCheckBox.resize(300, 170)
        self.centralwidget = QWidget(LayoutconCheckBox)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout_2 = QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.grupoOpciones = QGroupBox(self.centralwidget)
        self.grupoOpciones.setObjectName(u"grupoOpciones")
        self.verticalLayout = QVBoxLayout(self.grupoOpciones)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.checkPrimero = QCheckBox(self.grupoOpciones)
        self.checkPrimero.setObjectName(u"checkPrimero")

        self.verticalLayout.addWidget(self.checkPrimero)

        self.checkSegundo = QCheckBox(self.grupoOpciones)
        self.checkSegundo.setObjectName(u"checkSegundo")

        self.verticalLayout.addWidget(self.checkSegundo)

        self.checkTercero = QCheckBox(self.grupoOpciones)
        self.checkTercero.setObjectName(u"checkTercero")

        self.verticalLayout.addWidget(self.checkTercero)


        self.verticalLayout_2.addWidget(self.grupoOpciones)

        LayoutconCheckBox.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(LayoutconCheckBox)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 300, 20))
        LayoutconCheckBox.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(LayoutconCheckBox)
        self.statusbar.setObjectName(u"statusbar")
        LayoutconCheckBox.setStatusBar(self.statusbar)

        self.retranslateUi(LayoutconCheckBox)

        QMetaObject.connectSlotsByName(LayoutconCheckBox)
    # setupUi

    def retranslateUi(self, LayoutconCheckBox):
        LayoutconCheckBox.setWindowTitle(QCoreApplication.translate("LayoutconCheckBox", u"Layout con CheckBox", None))
        self.grupoOpciones.setTitle(QCoreApplication.translate("LayoutconCheckBox", u"Opciones", None))
        self.checkPrimero.setText(QCoreApplication.translate("LayoutconCheckBox", u"Primer CheckBox", None))
        self.checkSegundo.setText(QCoreApplication.translate("LayoutconCheckBox", u"Segundo CheckBox", None))
        self.checkTercero.setText(QCoreApplication.translate("LayoutconCheckBox", u"Tercer CheckBox", None))
    # retranslateUi

