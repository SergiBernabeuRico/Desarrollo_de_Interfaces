import sys
from PySide6.QtWidgets import QApplication, QMainWindow
from ejercicio6_ui import Ui_LayoutconCheckBox

class VentanaPrincipal(QMainWindow):
    def __init__(self):
        super().__init__()

        # Creo un objeto  de la interfaz generada por QtDesigner
        self.ui = Ui_LayoutconCheckBox()

        # Cargo el diseño dentro de esta ventana.
        self.ui.setupUi(self)

        # Conecto las señales stateChenged de los CheckBox
        self.ui.checkPrimero.stateChanged.connect(self.mostrar_checkBox_marcados)
        self.ui.checkSegundo.stateChanged.connect(self.mostrar_checkBox_marcados)
        self.ui.checkTercero.stateChanged.connect(self.mostrar_checkBox_marcados)

    def mostrar_checkBox_marcados(self, estado):

        # Creo una lista donde guardaré los textos de los CheckBox marcados
        marcados = []

        # Compruebo si los CheckBox está marcados,
        # si lo estan, añado su texto a la lista
        if self.ui.checkPrimero.isChecked():
            marcados.append(self.ui.checkPrimero.text())
        if self.ui.checkSegundo.isChecked():
            marcados.append(self.ui.checkSegundo.text())
        if self.ui.checkTercero.isChecked():
            marcados.append(self.ui.checkTercero.text())

        # Imprimo texto de CheckBox marcados si los hay
        if marcados:
            for texto in marcados:
                print(f"-{texto}")
        else:
            print("- Ninguno")

        # Doy una línea de espacio
        print()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = VentanaPrincipal()
    ventana.show()
    sys.exit(app.exec())

        


