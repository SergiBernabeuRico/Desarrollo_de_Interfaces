# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ejercicio2.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QHBoxLayout, QMainWindow, QMenuBar,
    QPushButton, QSizePolicy, QStatusBar, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(400, 120)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.horizontalLayout = QHBoxLayout(self.centralwidget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.btn4 = QPushButton(self.centralwidget)
        self.btn4.setObjectName(u"btn4")

        self.horizontalLayout.addWidget(self.btn4)

        self.btn3 = QPushButton(self.centralwidget)
        self.btn3.setObjectName(u"btn3")

        self.horizontalLayout.addWidget(self.btn3)

        self.btn2 = QPushButton(self.centralwidget)
        self.btn2.setObjectName(u"btn2")

        self.horizontalLayout.addWidget(self.btn2)

        self.btn1 = QPushButton(self.centralwidget)
        self.btn1.setObjectName(u"btn1")

        self.horizontalLayout.addWidget(self.btn1)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 400, 20))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Layout Horizontal con Botones", None))
        self.btn4.setText(QCoreApplication.translate("MainWindow", u"Cuatro", None))
        self.btn3.setText(QCoreApplication.translate("MainWindow", u"Tres", None))
        self.btn2.setText(QCoreApplication.translate("MainWindow", u"Dos", None))
        self.btn1.setText(QCoreApplication.translate("MainWindow", u"Uno", None))
    # retranslateUi

