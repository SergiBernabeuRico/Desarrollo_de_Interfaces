import sys
from PySide6.QtWidgets import QApplication, QMainWindow

# Importo la clase Ui_MainWindow desde el archivo generado automáticamente
# al compilar ejercicio2.ui con uic (los _ui.py generados automáticamente no se modifican)
from ejercicio2_ui import Ui_MainWindow

class ventanPrincipal(QMainWindow):
    def __init__(self):
        super().__init__()

        # Creo un objeto de la interfaz diseñada con QtDesigner
        self.ui = Ui_MainWindow()

        # Cargo la interfaz dentro de esta ventana
        self.ui.setupUi(self)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = ventanPrincipal()
    ventana.show()
    sys.exit(app.exec())
