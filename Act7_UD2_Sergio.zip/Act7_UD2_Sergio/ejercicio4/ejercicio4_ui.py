# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ejercicio4.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QMainWindow, QMenuBar, QSizePolicy,
    QStatusBar, QTabWidget, QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(380, 307)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setAutoFillBackground(True)
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.tabColores = QTabWidget(self.centralwidget)
        self.tabColores.setObjectName(u"tabColores")
        self.tabColores.setTabPosition(QTabWidget.TabPosition.West)
        self.tabRojo = QWidget()
        self.tabRojo.setObjectName(u"tabRojo")
        self.tabRojo.setStyleSheet(u"background-color: red;")
        self.tabColores.addTab(self.tabRojo, "")
        self.tabVerde = QWidget()
        self.tabVerde.setObjectName(u"tabVerde")
        self.tabVerde.setStyleSheet(u"background-color: green;")
        self.tabColores.addTab(self.tabVerde, "")
        self.tabAzul = QWidget()
        self.tabAzul.setObjectName(u"tabAzul")
        self.tabAzul.setStyleSheet(u"background-color: blue\n"
";")
        self.tabColores.addTab(self.tabAzul, "")
        self.tabAmarillo = QWidget()
        self.tabAmarillo.setObjectName(u"tabAmarillo")
        self.tabAmarillo.setStyleSheet(u"background-color: yellow;")
        self.tabColores.addTab(self.tabAmarillo, "")

        self.verticalLayout.addWidget(self.tabColores)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 380, 20))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        self.tabColores.setCurrentIndex(3)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Layout Vertical con Pesta\u00f1as", None))
        self.tabColores.setTabText(self.tabColores.indexOf(self.tabRojo), QCoreApplication.translate("MainWindow", u"Rojo", None))
        self.tabColores.setTabText(self.tabColores.indexOf(self.tabVerde), QCoreApplication.translate("MainWindow", u"Verde", None))
        self.tabColores.setTabText(self.tabColores.indexOf(self.tabAzul), QCoreApplication.translate("MainWindow", u"Azul", None))
        self.tabColores.setTabText(self.tabColores.indexOf(self.tabAmarillo), QCoreApplication.translate("MainWindow", u"Amarillo", None))
    # retranslateUi

