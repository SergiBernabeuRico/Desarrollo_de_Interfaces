import sys
from PySide6.QtWidgets import QApplication, QMainWindow
from ejercicio4_ui import Ui_MainWindow

# Importo la clase Ui_MainWindow desde el archivo generado automáticamente
# al compilar ejercicio4.ui con uic (los _ui.py generados automáticamente no se modifican)
class VentanPrincipal(QMainWindow):
    def __init__(self):
        super().__init__()

        # Creo un objeto de la interfaz diseñada con QtDesigner
        self.ui = Ui_MainWindow()
        # Cargo el objeto en esta ventana
        self.ui.setupUi(self)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = VentanPrincipal()
    ventana.show()
    sys.exit(app.exec())
