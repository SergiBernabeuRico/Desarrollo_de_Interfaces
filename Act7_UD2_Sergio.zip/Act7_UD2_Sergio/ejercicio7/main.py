import sys
from PySide6.QtWidgets import QApplication, QMainWindow, QLabel, QGridLayout, QSizePolicy

# Importo la interfaz generada automáticamente desde ejercicio7.py
from ejercicio7_ui import Ui_MainWindow

class VentanaPrincipal(QMainWindow):
    def __init__(self):
        super().__init__()

        # Creo un objeto de la interfaz generada por Qt Designer
        self.ui = Ui_MainWindow()
        # Cargo el diseño dentro de la ventana
        self.ui.setupUi(self)

        # Llamo al método que construye el tablero
        self.crear_tablero()
    
    def crear_tablero(self):
        # Creo un layout de cuadricula
        grid = QGridLayout()

        # Quito el espacio entre las casillas
        grid.setSpacing(0)

        # Quito márgenes internos del layout
        # Orden (izq, arriba, drch, bajo)
        grid.setContentsMargins(0,0,0,0)

        # Recorro las filas del tablero
        for fila in range(8): # Recorro las columnas del tablero
            for columna in range(8):
                casilla = QLabel() # Creo la casilla
                casilla.setSizePolicy( # Permito que crezcan las casillas si crece la ventana
                    QSizePolicy.Expanding,
                    QSizePolicy.Expanding
                )

                # Para alternar los colores que le damos a las casillas
                # utilizo la suma de fila + columna % 2.
                # Si la suma es par, blanco. Si no, negro
                if (fila + columna) % 2 == 0:
                    casilla.setStyleSheet("background-color: white;")
                else:
                    casilla.setStyleSheet("background-color: black;")

                # Añado cada casilla al GridLayout
                # Esto coloca cada casilla en su posición correspondiente
                grid.addWidget(casilla, fila, columna)

        # Hago que todas las casillas tengan el mismo peso
        # Así crecen igual si se agranda la ventana
        for columna in range(8):
            grid.setColumnStretch(columna, 1)

        for fila in range(8):
            grid.setColumnStretch(fila, 1)

        # Coloco el GridLayout dentro del contenedor creado con Qt Designer
        self.ui.contenedorTablero.setLayout(grid)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = VentanaPrincipal()
    ventana.show()
    sys.exit(app.exec())




        
