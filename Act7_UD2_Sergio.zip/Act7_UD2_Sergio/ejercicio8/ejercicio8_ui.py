# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'ejercicio8.ui'
##
## Created by: Qt User Interface Compiler version 6.10.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QHBoxLayout, QLabel,
    QListWidget, QListWidgetItem, QMainWindow, QMenuBar,
    QPushButton, QSizePolicy, QStackedWidget, QStatusBar,
    QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(650, 245)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.contenedorPrincipal = QWidget(self.centralwidget)
        self.contenedorPrincipal.setObjectName(u"contenedorPrincipal")
        self.horizontalLayout_2 = QHBoxLayout(self.contenedorPrincipal)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.listaMenu = QListWidget(self.contenedorPrincipal)
        QListWidgetItem(self.listaMenu)
        QListWidgetItem(self.listaMenu)
        QListWidgetItem(self.listaMenu)
        self.listaMenu.setObjectName(u"listaMenu")
        self.listaMenu.setMinimumSize(QSize(150, 0))
        self.listaMenu.setMaximumSize(QSize(180, 16777215))

        self.horizontalLayout_2.addWidget(self.listaMenu)

        self.paginas = QStackedWidget(self.contenedorPrincipal)
        self.paginas.setObjectName(u"paginas")
        self.paginaInicio = QWidget()
        self.paginaInicio.setObjectName(u"paginaInicio")
        self.labelInicio = QLabel(self.paginaInicio)
        self.labelInicio.setObjectName(u"labelInicio")
        self.labelInicio.setGeometry(QRect(10, 10, 171, 16))
        self.btnCambiarMensaje = QPushButton(self.paginaInicio)
        self.btnCambiarMensaje.setObjectName(u"btnCambiarMensaje")
        self.btnCambiarMensaje.setGeometry(QRect(10, 40, 411, 23))
        self.paginas.addWidget(self.paginaInicio)
        self.paginaInformacion = QWidget()
        self.paginaInformacion.setObjectName(u"paginaInformacion")
        self.labelInfo = QLabel(self.paginaInformacion)
        self.labelInfo.setObjectName(u"labelInfo")
        self.labelInfo.setGeometry(QRect(10, 10, 331, 16))
        self.btnAbrirWeb = QPushButton(self.paginaInformacion)
        self.btnAbrirWeb.setObjectName(u"btnAbrirWeb")
        self.btnAbrirWeb.setGeometry(QRect(10, 40, 411, 23))
        self.paginas.addWidget(self.paginaInformacion)
        self.paginaConfiguracion = QWidget()
        self.paginaConfiguracion.setObjectName(u"paginaConfiguracion")
        self.checkModoOscuro = QCheckBox(self.paginaConfiguracion)
        self.checkModoOscuro.setObjectName(u"checkModoOscuro")
        self.checkModoOscuro.setGeometry(QRect(60, 10, 191, 20))
        self.checkNotificaciones = QCheckBox(self.paginaConfiguracion)
        self.checkNotificaciones.setObjectName(u"checkNotificaciones")
        self.checkNotificaciones.setGeometry(QRect(60, 50, 191, 20))
        self.checkActualizaciones = QCheckBox(self.paginaConfiguracion)
        self.checkActualizaciones.setObjectName(u"checkActualizaciones")
        self.checkActualizaciones.setGeometry(QRect(60, 90, 191, 20))
        self.btnMostrarSeleccion = QPushButton(self.paginaConfiguracion)
        self.btnMostrarSeleccion.setObjectName(u"btnMostrarSeleccion")
        self.btnMostrarSeleccion.setGeometry(QRect(60, 130, 181, 23))
        self.paginas.addWidget(self.paginaConfiguracion)

        self.horizontalLayout_2.addWidget(self.paginas)


        self.verticalLayout.addWidget(self.contenedorPrincipal)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 650, 20))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        self.paginas.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Menu lateral con QStackedWidget", None))

        __sortingEnabled = self.listaMenu.isSortingEnabled()
        self.listaMenu.setSortingEnabled(False)
        ___qlistwidgetitem = self.listaMenu.item(0)
        ___qlistwidgetitem.setText(QCoreApplication.translate("MainWindow", u"Inicio", None));
        ___qlistwidgetitem1 = self.listaMenu.item(1)
        ___qlistwidgetitem1.setText(QCoreApplication.translate("MainWindow", u"Informaci\u00f3n", None));
        ___qlistwidgetitem2 = self.listaMenu.item(2)
        ___qlistwidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Configuraci\u00f3n", None));
        self.listaMenu.setSortingEnabled(__sortingEnabled)

        self.labelInicio.setText(QCoreApplication.translate("MainWindow", u"Bienvenido a la aplicaci\u00f3n", None))
        self.btnCambiarMensaje.setText(QCoreApplication.translate("MainWindow", u"Cambia el mensaje", None))
        self.labelInfo.setText(QCoreApplication.translate("MainWindow", u"Esta aplicaci\u00f3n muestra informaci\u00f3n del IES Paco Moll\u00e1", None))
        self.btnAbrirWeb.setText(QCoreApplication.translate("MainWindow", u"Abrir web del IES Paco Moll\u00e1", None))
        self.checkModoOscuro.setText(QCoreApplication.translate("MainWindow", u"Activar modo oscuro", None))
        self.checkNotificaciones.setText(QCoreApplication.translate("MainWindow", u"Activar notificaciones", None))
        self.checkActualizaciones.setText(QCoreApplication.translate("MainWindow", u"Actualizaciones autom\u00e1ticas", None))
        self.btnMostrarSeleccion.setText(QCoreApplication.translate("MainWindow", u"Mostrar selecci\u00f3n", None))
    # retranslateUi

