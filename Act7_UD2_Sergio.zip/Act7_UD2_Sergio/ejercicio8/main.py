import sys
from PySide6.QtWidgets import QApplication, QMainWindow

# Para permitir abrir una página web
from PySide6.QtGui import QDesktopServices
# Para crear una URL válida que Qt pueda abrir
from PySide6.QtCore import QUrl

# Interfaz generada desde ejercicio8
from ejercicio8_ui import Ui_MainWindow

class VentanaPrincipal(QMainWindow):
    def __init__(self):
        super().__init__()

        # Creo el objeto de la interfaz generada por Qt
        self.ui = Ui_MainWindow()

        # Cargo el diseño dentro de esta ventana,
        # después de esta línea ya existen listaMenu,
        # paginas, labelInicio, botones y checkBox
        self.ui.setupUi(self)

        # Muestro la 1ª página del QStackedWidget
        # El indice 0 es la paginaInicio
        self.ui.paginas.setCurrentIndex(0)

        # Conecto el cambio de selección del menu lateral con 
        # el método que cambia la página visible
        self.ui.listaMenu.currentRowChanged.connect(self.cambiar_pagina)

        # Conecto el botón de la página Inicio
        # cuando se pulsa el botón, cambia el texto del label
        self.ui.btnCambiarMensaje.clicked.connect(self.cambiar_mensaje_inicio)

        # Conecto el botón de la página Información,
        # Cuando se pulsa el botón, abre la web del IES
        self.ui.btnAbrirWeb.clicked.connect(self.abrir_web_ies)

        # Conecto el botón de la página Configuración
        # cuando se pulse el botón, se imprimirán los checkbox marcados
        self.ui.btnMostrarSeleccion.clicked.connect(self.mostrar_configuracion)

    def cambiar_pagina(self, indice):

        # Cambio la página visible del QStackedWidget,
        # el índice del menú coincide con el índice de la página
        self.ui.paginas.setCurrentIndex(indice)

    def cambiar_mensaje_inicio(self):

        # Cambio el texto del QLabel
        self.ui.labelInicio.setText("Has hecho clic en el botón")

    def abrir_web_ies(self):

        # Creo la URL del IES Paco Mollá
        url = QUrl("https://iespacomolla.es/")

        # Abro la URL con el navegador del sistema
        QDesktopServices.openUrl(url)

    def mostrar_configuracion(self):

        # Creo la lista vacía para guardar los textos
        # de los checkbox que estén seleccionados
        seleccionados = []

        # Compruebo si el checkbox de modo oscuro está marcado
        if self.ui.checkModoOscuro.isChecked():

            # Si está marcado, añado su texto a la lista
            seleccionados.append(self.ui.checkModoOscuro.text())

        # Compruebo si el checkbox de notificaciones está marcado
        if self.ui.checkNotificaciones.isChecked():

            # Si está marcado, añado su texto a la lista
            seleccionados.append(self.ui.checkNotificaciones.text())

        # Compruebo si el checkbox de actualizaciones está marcado
        if self.ui.checkActualizaciones.isChecked():

            # Si está marcado, añadimos su texto a la lista
            seleccionados.append(self.ui.checkActualizaciones.text())

        # Imprimo una cabecera para organizar la salida
        print("Checkbox seleccionados:")

        # Si hay elementos en la lista, se muestran
        if seleccionados:
            for texto in seleccionados:
                # ISe imprime cada opción seleccionada
                print(f"- {texto}")

        # Si no hay ninguno seleccionado, se imprime - Ninguno
        else:
            print("- Ninguno")

        # Línea vacía para separar cada pulsación
        print()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    ventana = VentanaPrincipal()
    ventana.show()
    sys.exit(app.exec())