namespace Act3_MaquinaVending
{
    public partial class Form1 : Form
    {
        // stock per defecte 
        int stockCola = 20;
        int stockUp = 20;
        int stockAqua = 20;
        int stockFanta = 20;
        int stockZero = 20;
        double total = 0.0;
        public Form1()
        {
            InitializeComponent();

            textBoxCoca.Text = stockCola.ToString();
            textBoxUp.Text = stockUp.ToString();
            textBoxfanta.Text = stockFanta.ToString();
            textBoxZero.Text = stockZero.ToString();
            textBoxAqua.Text = stockAqua.ToString();

            textBoxTotal.Text = total.ToString();
        }

        private void pictureBoxCoca_Click(object sender, EventArgs e)
        {
            double precio = 1.00;

            if (stockCola > 0)
            {
                stockCola--;
                textBoxCoca.Text = stockCola.ToString();

                total += precio;
                textBoxTotal.Text = total.ToString("0.00") + " �";
            }
            else
            {
                MessageBox.Show("Producte fora d'estoc");
            }
        }

        private void pictureBoxUp_Click(object sender, EventArgs e)
        {
            double precio = 1.00;

            if (stockUp > 0)
            {
                stockUp--;
                textBoxUp.Text = stockUp.ToString();

                total += precio;
                textBoxTotal.Text = total.ToString("0.00") + " �";
            }
            else
            {
                MessageBox.Show("Producte fora d'estoc");
            }
        }

        private void pictureBoxFanta_Click(object sender, EventArgs e)
        {
            double precio = 1.00;

            if (stockFanta > 0)
            {
                stockFanta--;
                textBoxfanta.Text = stockFanta.ToString();

                total += precio;
                textBoxTotal.Text = total.ToString("0.00") + " �";
            }
            else
            {
                MessageBox.Show("Producte fora d'estoc");
            }
        }

        private void pictureBoxZero_Click(object sender, EventArgs e)
        {
            double precio = 1.50;

            if (stockZero > 0)
            {
                stockZero--;
                textBoxZero.Text = stockZero.ToString();

                total += precio;
                textBoxTotal.Text = total.ToString("0.00") + " �";
            }
            else
            {
                MessageBox.Show("Producte fora d'estoc");
            }
        }

        private void pictureBoxAqua_Click(object sender, EventArgs e)
        {
            double precio = 1.50;

            if (stockAqua > 0)
            {
                stockAqua--;
                textBoxAqua.Text = stockAqua.ToString();

                total += precio;
                textBoxTotal.Text = total.ToString("0.00") + " �";
            }
        }

        private void btnNouClient_Click(object sender, EventArgs e)
        {
            total = 0.0;
            textBoxTotal.Text = "0.00 �";
        }

        private void btnEixir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
