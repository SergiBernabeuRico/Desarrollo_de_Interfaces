﻿namespace Act3_MaquinaVending
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            lblTitulo = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            panel1 = new Panel();
            pictureBoxCoca = new PictureBox();
            textBoxCoca = new TextBox();
            lblQueden1 = new Label();
            lblPrecio1 = new Label();
            panel2 = new Panel();
            pictureBoxUp = new PictureBox();
            textBoxUp = new TextBox();
            lblQueden2 = new Label();
            lblPrecio2 = new Label();
            panel3 = new Panel();
            pictureBoxFanta = new PictureBox();
            textBoxfanta = new TextBox();
            lblQueden3 = new Label();
            lblPrecio3 = new Label();
            panel4 = new Panel();
            pictureBoxZero = new PictureBox();
            textBoxZero = new TextBox();
            lblQueden4 = new Label();
            lblPrecio4 = new Label();
            panel5 = new Panel();
            pictureBoxAqua = new PictureBox();
            textBoxAqua = new TextBox();
            lblQueden5 = new Label();
            lblPrecio5 = new Label();
            panel6 = new Panel();
            textBoxTotal = new TextBox();
            lblTotalPagar = new Label();
            btnNouClient = new Button();
            btnEixir = new Button();
            tableLayoutPanel1.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCoca).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxUp).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxFanta).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxZero).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxAqua).BeginInit();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            lblTitulo.Location = new Point(97, 9);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.RightToLeft = RightToLeft.No;
            lblTitulo.Size = new Size(317, 31);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "Seleccione una beguda";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(panel1, 0, 0);
            tableLayoutPanel1.Controls.Add(panel2, 1, 0);
            tableLayoutPanel1.Controls.Add(panel3, 0, 1);
            tableLayoutPanel1.Controls.Add(panel4, 1, 1);
            tableLayoutPanel1.Controls.Add(panel5, 0, 2);
            tableLayoutPanel1.Controls.Add(panel6, 1, 2);
            tableLayoutPanel1.Location = new Point(34, 58);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Size = new Size(440, 423);
            tableLayoutPanel1.TabIndex = 1;
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBoxCoca);
            panel1.Controls.Add(textBoxCoca);
            panel1.Controls.Add(lblQueden1);
            panel1.Controls.Add(lblPrecio1);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(214, 125);
            panel1.TabIndex = 0;
            // 
            // pictureBoxCoca
            // 
            pictureBoxCoca.Image = (Image)resources.GetObject("pictureBoxCoca.Image");
            pictureBoxCoca.Location = new Point(0, 3);
            pictureBoxCoca.Name = "pictureBoxCoca";
            pictureBoxCoca.Size = new Size(106, 119);
            pictureBoxCoca.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxCoca.TabIndex = 3;
            pictureBoxCoca.TabStop = false;
            pictureBoxCoca.Click += pictureBoxCoca_Click;
            // 
            // textBoxCoca
            // 
            textBoxCoca.Location = new Point(115, 86);
            textBoxCoca.Name = "textBoxCoca";
            textBoxCoca.Size = new Size(87, 27);
            textBoxCoca.TabIndex = 2;
            textBoxCoca.TextAlign = HorizontalAlignment.Center;
            // 
            // lblQueden1
            // 
            lblQueden1.AutoSize = true;
            lblQueden1.Location = new Point(132, 63);
            lblQueden1.Name = "lblQueden1";
            lblQueden1.Size = new Size(59, 20);
            lblQueden1.TabIndex = 1;
            lblQueden1.Text = "queden";
            // 
            // lblPrecio1
            // 
            lblPrecio1.AutoSize = true;
            lblPrecio1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblPrecio1.Location = new Point(143, 27);
            lblPrecio1.Name = "lblPrecio1";
            lblPrecio1.Size = new Size(53, 20);
            lblPrecio1.TabIndex = 0;
            lblPrecio1.Text = "1.00 €";
            // 
            // panel2
            // 
            panel2.Controls.Add(pictureBoxUp);
            panel2.Controls.Add(textBoxUp);
            panel2.Controls.Add(lblQueden2);
            panel2.Controls.Add(lblPrecio2);
            panel2.Location = new Point(223, 3);
            panel2.Name = "panel2";
            panel2.Size = new Size(214, 125);
            panel2.TabIndex = 1;
            // 
            // pictureBoxUp
            // 
            pictureBoxUp.Image = (Image)resources.GetObject("pictureBoxUp.Image");
            pictureBoxUp.Location = new Point(0, 3);
            pictureBoxUp.Name = "pictureBoxUp";
            pictureBoxUp.Size = new Size(106, 119);
            pictureBoxUp.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxUp.TabIndex = 4;
            pictureBoxUp.TabStop = false;
            pictureBoxUp.Click += pictureBoxUp_Click;
            // 
            // textBoxUp
            // 
            textBoxUp.Location = new Point(114, 86);
            textBoxUp.Name = "textBoxUp";
            textBoxUp.Size = new Size(87, 27);
            textBoxUp.TabIndex = 3;
            textBoxUp.TextAlign = HorizontalAlignment.Center;
            // 
            // lblQueden2
            // 
            lblQueden2.AutoSize = true;
            lblQueden2.Location = new Point(131, 63);
            lblQueden2.Name = "lblQueden2";
            lblQueden2.Size = new Size(59, 20);
            lblQueden2.TabIndex = 2;
            lblQueden2.Text = "queden";
            // 
            // lblPrecio2
            // 
            lblPrecio2.AutoSize = true;
            lblPrecio2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblPrecio2.Location = new Point(142, 27);
            lblPrecio2.Name = "lblPrecio2";
            lblPrecio2.Size = new Size(53, 20);
            lblPrecio2.TabIndex = 1;
            lblPrecio2.Text = "1.00 €";
            // 
            // panel3
            // 
            panel3.Controls.Add(pictureBoxFanta);
            panel3.Controls.Add(textBoxfanta);
            panel3.Controls.Add(lblQueden3);
            panel3.Controls.Add(lblPrecio3);
            panel3.Location = new Point(3, 143);
            panel3.Name = "panel3";
            panel3.Size = new Size(214, 125);
            panel3.TabIndex = 2;
            // 
            // pictureBoxFanta
            // 
            pictureBoxFanta.Image = (Image)resources.GetObject("pictureBoxFanta.Image");
            pictureBoxFanta.Location = new Point(3, 3);
            pictureBoxFanta.Name = "pictureBoxFanta";
            pictureBoxFanta.Size = new Size(106, 119);
            pictureBoxFanta.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxFanta.TabIndex = 4;
            pictureBoxFanta.TabStop = false;
            pictureBoxFanta.Click += pictureBoxFanta_Click;
            // 
            // textBoxfanta
            // 
            textBoxfanta.Location = new Point(115, 85);
            textBoxfanta.Name = "textBoxfanta";
            textBoxfanta.Size = new Size(87, 27);
            textBoxfanta.TabIndex = 3;
            textBoxfanta.TextAlign = HorizontalAlignment.Center;
            // 
            // lblQueden3
            // 
            lblQueden3.AutoSize = true;
            lblQueden3.Location = new Point(132, 62);
            lblQueden3.Name = "lblQueden3";
            lblQueden3.Size = new Size(59, 20);
            lblQueden3.TabIndex = 2;
            lblQueden3.Text = "queden";
            // 
            // lblPrecio3
            // 
            lblPrecio3.AutoSize = true;
            lblPrecio3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblPrecio3.Location = new Point(143, 25);
            lblPrecio3.Name = "lblPrecio3";
            lblPrecio3.Size = new Size(53, 20);
            lblPrecio3.TabIndex = 1;
            lblPrecio3.Text = "1.00 €";
            // 
            // panel4
            // 
            panel4.Controls.Add(pictureBoxZero);
            panel4.Controls.Add(textBoxZero);
            panel4.Controls.Add(lblQueden4);
            panel4.Controls.Add(lblPrecio4);
            panel4.Location = new Point(223, 143);
            panel4.Name = "panel4";
            panel4.Size = new Size(214, 125);
            panel4.TabIndex = 3;
            // 
            // pictureBoxZero
            // 
            pictureBoxZero.Image = (Image)resources.GetObject("pictureBoxZero.Image");
            pictureBoxZero.Location = new Point(2, 3);
            pictureBoxZero.Name = "pictureBoxZero";
            pictureBoxZero.Size = new Size(106, 119);
            pictureBoxZero.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxZero.TabIndex = 4;
            pictureBoxZero.TabStop = false;
            pictureBoxZero.Click += pictureBoxZero_Click;
            // 
            // textBoxZero
            // 
            textBoxZero.Location = new Point(114, 85);
            textBoxZero.Name = "textBoxZero";
            textBoxZero.Size = new Size(87, 27);
            textBoxZero.TabIndex = 3;
            textBoxZero.TextAlign = HorizontalAlignment.Center;
            // 
            // lblQueden4
            // 
            lblQueden4.AutoSize = true;
            lblQueden4.Location = new Point(131, 62);
            lblQueden4.Name = "lblQueden4";
            lblQueden4.Size = new Size(59, 20);
            lblQueden4.TabIndex = 2;
            lblQueden4.Text = "queden";
            // 
            // lblPrecio4
            // 
            lblPrecio4.AutoSize = true;
            lblPrecio4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblPrecio4.Location = new Point(142, 25);
            lblPrecio4.Name = "lblPrecio4";
            lblPrecio4.Size = new Size(53, 20);
            lblPrecio4.TabIndex = 1;
            lblPrecio4.Text = "1.50 €";
            // 
            // panel5
            // 
            panel5.Controls.Add(pictureBoxAqua);
            panel5.Controls.Add(textBoxAqua);
            panel5.Controls.Add(lblQueden5);
            panel5.Controls.Add(lblPrecio5);
            panel5.Location = new Point(3, 283);
            panel5.Name = "panel5";
            panel5.Size = new Size(214, 125);
            panel5.TabIndex = 4;
            // 
            // pictureBoxAqua
            // 
            pictureBoxAqua.Image = (Image)resources.GetObject("pictureBoxAqua.Image");
            pictureBoxAqua.Location = new Point(3, 3);
            pictureBoxAqua.Name = "pictureBoxAqua";
            pictureBoxAqua.Size = new Size(106, 119);
            pictureBoxAqua.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxAqua.TabIndex = 4;
            pictureBoxAqua.TabStop = false;
            pictureBoxAqua.Click += pictureBoxAqua_Click;
            // 
            // textBoxAqua
            // 
            textBoxAqua.Location = new Point(115, 87);
            textBoxAqua.Name = "textBoxAqua";
            textBoxAqua.Size = new Size(87, 27);
            textBoxAqua.TabIndex = 3;
            textBoxAqua.TextAlign = HorizontalAlignment.Center;
            // 
            // lblQueden5
            // 
            lblQueden5.AutoSize = true;
            lblQueden5.Location = new Point(132, 64);
            lblQueden5.Name = "lblQueden5";
            lblQueden5.Size = new Size(59, 20);
            lblQueden5.TabIndex = 2;
            lblQueden5.Text = "queden";
            // 
            // lblPrecio5
            // 
            lblPrecio5.AutoSize = true;
            lblPrecio5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblPrecio5.Location = new Point(143, 25);
            lblPrecio5.Name = "lblPrecio5";
            lblPrecio5.Size = new Size(53, 20);
            lblPrecio5.TabIndex = 1;
            lblPrecio5.Text = "1.50 €";
            // 
            // panel6
            // 
            panel6.Controls.Add(textBoxTotal);
            panel6.Controls.Add(lblTotalPagar);
            panel6.Location = new Point(223, 283);
            panel6.Name = "panel6";
            panel6.Size = new Size(214, 125);
            panel6.TabIndex = 5;
            // 
            // textBoxTotal
            // 
            textBoxTotal.Location = new Point(63, 64);
            textBoxTotal.Name = "textBoxTotal";
            textBoxTotal.Size = new Size(87, 27);
            textBoxTotal.TabIndex = 3;
            textBoxTotal.TextAlign = HorizontalAlignment.Center;
            // 
            // lblTotalPagar
            // 
            lblTotalPagar.AutoSize = true;
            lblTotalPagar.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            lblTotalPagar.Location = new Point(54, 25);
            lblTotalPagar.Name = "lblTotalPagar";
            lblTotalPagar.Size = new Size(103, 20);
            lblTotalPagar.TabIndex = 2;
            lblTotalPagar.Text = "Total A pagar";
            // 
            // btnNouClient
            // 
            btnNouClient.Location = new Point(97, 514);
            btnNouClient.Name = "btnNouClient";
            btnNouClient.Size = new Size(115, 29);
            btnNouClient.TabIndex = 2;
            btnNouClient.Text = "Nou client";
            btnNouClient.UseVisualStyleBackColor = true;
            btnNouClient.Click += btnNouClient_Click;
            // 
            // btnEixir
            // 
            btnEixir.Location = new Point(320, 514);
            btnEixir.Name = "btnEixir";
            btnEixir.Size = new Size(115, 29);
            btnEixir.TabIndex = 3;
            btnEixir.Text = "Eixir";
            btnEixir.UseVisualStyleBackColor = true;
            btnEixir.Click += btnEixir_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(518, 570);
            Controls.Add(btnEixir);
            Controls.Add(btnNouClient);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(lblTitulo);
            Name = "Form1";
            Text = "Form1";
            tableLayoutPanel1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxCoca).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxUp).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxFanta).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxZero).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxAqua).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitulo;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel panel1;
        private Label lblPrecio1;
        private Panel panel2;
        private Label lblPrecio2;
        private Panel panel3;
        private Label lblPrecio3;
        private Panel panel4;
        private Label lblPrecio4;
        private Panel panel5;
        private Label lblPrecio5;
        private Panel panel6;
        private Label lblPrecio6;
        private Label lblQueden1;
        private Label lblQueden2;
        private Label lblQueden3;
        private Label lblQueden4;
        private Label lblQueden5;
        private Label lblTotalPagar;
        private TextBox textBoxCoca;
        private TextBox textBoxUp;
        private TextBox textBoxfanta;
        private TextBox textBoxZero;
        private TextBox textBoxAqua;
        private TextBox textBoxTotal;
        private Button btnNouClient;
        private Button btnEixir;
        private PictureBox pictureBoxCoca;
        private PictureBox pictureBoxUp;
        private PictureBox pictureBoxFanta;
        private PictureBox pictureBoxZero;
        private PictureBox pictureBoxAqua;
    }
}
