// Necesitamos esta librer�a para usar CultureInfo y NumberStyles,
// que nos ayudan a convertir texto a n�mero de forma segura.
using System.Globalization;
using System.Drawing;

namespace Act1_Conversor
{
    // "partial" significa que esta clase est� dividida en dos archivos:
    // - Form1.cs (este archivo, donde va la l�gica)
    // - Form1.Designer.cs (donde se crean los controles: txtCelsius, btnConvertir, lblResultado, etc.)
    public partial class Form1 : Form
    {
        // Constructor: se ejecuta cuando se crea el formulario
        public Form1()
        {
            InitializeComponent();      // Crea y coloca los controles del formulario (Designer)
            lblResultado.Text = "";     // Dejamos el label del resultado vac�o al iniciar
        }

        // Este m�todo se ejecuta cuando el usuario hace clic en el bot�n "Convertir"
        private void btnConvertir_Click(object sender, EventArgs e)
        {
            // 1) Leemos el texto del TextBox y eliminamos espacios al inicio/final (por si el usuario escribe " 12 ")
            string texto = txtCelsius.Text.Trim();

            // 2) Validaci�n: si el campo est� vac�o, mostramos un error y salimos del m�todo
            if (string.IsNullOrEmpty(texto))
            {
                MessageBox.Show("El campo Celsius no puede estar vac�o.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                txtCelsius.Focus(); // Coloca el cursor de nuevo en el TextBox
                return;             // Sale del m�todo: no seguimos con la conversi�n
            }

            // 3) Normalizamos el separador decimal:
            // En Espa�a es com�n usar coma (12,5) pero muchos parseos esperan punto (12.5).
            // Reemplazamos ',' por '.' para poder convertir usando InvariantCulture.
            string normalizado = texto.Replace(',', '.');

            // 4) Convertimos el texto a n�mero de forma segura con TryParse:
            // - Si puede convertir, devuelve true y guarda el resultado en "celsius".
            // - Si NO puede convertir, devuelve false.
            //
            // NumberStyles.Float permite n�meros decimales, negativos, etc.
            // CultureInfo.InvariantCulture fuerza el formato con punto como separador decimal.
            //
            // El "!" significa "NO", por lo que entramos al if cuando la conversi�n FALLA.
            if (!double.TryParse(normalizado, NumberStyles.Float, CultureInfo.InvariantCulture, out double celsius))
            {
                MessageBox.Show("Introduce un n�mero v�lido (por ejemplo 12,5).", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                txtCelsius.SelectAll(); // Selecciona todo el texto para que el usuario lo reescriba r�pido
                txtCelsius.Focus();     // Devuelve el cursor al TextBox
                return;                 // Salimos del m�todo
            }

            // 5) Conversi�n de Celsius a Fahrenheit:
            // F�rmula: F = (1.8 * C) + 32
            double fahrenheit = (1.8 * celsius) + 32;

            // 6) Formateamos la salida a 2 decimales y a�adimos la unidad �F
            // {fahrenheit:0.00} -> muestra siempre 2 decimales
            string salida = $"La conversi�n a farenheit es: {fahrenheit:0.00} �F";

            // 7) Mostramos el resultado en el label del formulario
            lblResultado.Text = salida;

            // 8) Y tambi�n lo mostramos en una ventana emergente informativa
            MessageBox.Show($"Resultado: {salida}", "Conversi�n realizada",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
