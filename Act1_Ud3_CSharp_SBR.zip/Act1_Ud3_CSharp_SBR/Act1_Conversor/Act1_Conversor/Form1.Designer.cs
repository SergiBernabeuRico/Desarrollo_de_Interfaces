﻿namespace Act1_Conversor
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCelsius = new TextBox();
            btnConvertir = new Button();
            label1 = new Label();
            lblResultado = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // txtCelsius
            // 
            txtCelsius.Location = new Point(308, 76);
            txtCelsius.Name = "txtCelsius";
            txtCelsius.Size = new Size(125, 27);
            txtCelsius.TabIndex = 0;
            // 
            // btnConvertir
            // 
            btnConvertir.Location = new Point(308, 130);
            btnConvertir.Name = "btnConvertir";
            btnConvertir.Size = new Size(94, 29);
            btnConvertir.TabIndex = 1;
            btnConvertir.Text = "Convertir";
            btnConvertir.UseVisualStyleBackColor = true;
            btnConvertir.Click += btnConvertir_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(64, 79);
            label1.Name = "label1";
            label1.Size = new Size(238, 20);
            label1.TabIndex = 2;
            label1.Text = "Introdueix els graus per a convertir";
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Location = new Point(439, 79);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(0, 20);
            lblResultado.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Showcard Gothic", 24F, FontStyle.Bold);
            label2.ForeColor = Color.CornflowerBlue;
            label2.Location = new Point(30, 9);
            label2.Name = "label2";
            label2.Size = new Size(758, 50);
            label2.TabIndex = 4;
            label2.Text = "Conversor de grados a Farenheit";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 206);
            Controls.Add(label2);
            Controls.Add(lblResultado);
            Controls.Add(label1);
            Controls.Add(btnConvertir);
            Controls.Add(txtCelsius);
            Name = "Form1";
            Text = "Conversor de graus";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtCelsius;
        private Button btnConvertir;
        private Label label1;
        private Label lblResultado;
        private Label label2;
    }
}
