﻿namespace Act2_CalcularMassaCorporal
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox1 = new PictureBox();
            lblIntroPes = new Label();
            txtBoxKg = new TextBox();
            lblIntroAlçada = new Label();
            txtBoxM = new TextBox();
            btnCalcular = new Button();
            btnNetejar = new Button();
            lblIndex = new Label();
            txtBoxIndexMassa = new TextBox();
            lblEstat = new Label();
            lblEstatFinal = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(194, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(262, 182);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // lblIntroPes
            // 
            lblIntroPes.AutoSize = true;
            lblIntroPes.Location = new Point(82, 214);
            lblIntroPes.Name = "lblIntroPes";
            lblIntroPes.Size = new Size(163, 20);
            lblIntroPes.TabIndex = 1;
            lblIntroPes.Text = "Introduix el pes (En Kg)";
            // 
            // txtBoxKg
            // 
            txtBoxKg.Location = new Point(414, 214);
            txtBoxKg.Name = "txtBoxKg";
            txtBoxKg.Size = new Size(125, 27);
            txtBoxKg.TabIndex = 2;
            // 
            // lblIntroAlçada
            // 
            lblIntroAlçada.AutoSize = true;
            lblIntroAlçada.Location = new Point(82, 268);
            lblIntroAlçada.Name = "lblIntroAlçada";
            lblIntroAlçada.Size = new Size(212, 20);
            lblIntroAlçada.TabIndex = 3;
            lblIntroAlçada.Text = "Introduix la teua alçada (En m)";
            // 
            // txtBoxM
            // 
            txtBoxM.Location = new Point(414, 265);
            txtBoxM.Name = "txtBoxM";
            txtBoxM.Size = new Size(125, 27);
            txtBoxM.TabIndex = 4;
            // 
            // btnCalcular
            // 
            btnCalcular.BackColor = Color.LawnGreen;
            btnCalcular.Location = new Point(104, 330);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(141, 39);
            btnCalcular.TabIndex = 5;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = false;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // btnNetejar
            // 
            btnNetejar.BackColor = Color.Red;
            btnNetejar.Location = new Point(414, 330);
            btnNetejar.Name = "btnNetejar";
            btnNetejar.Size = new Size(103, 39);
            btnNetejar.TabIndex = 6;
            btnNetejar.Text = "Netejar";
            btnNetejar.UseVisualStyleBackColor = false;
            btnNetejar.Click += btnNetejar_Click;
            // 
            // lblIndex
            // 
            lblIndex.AutoSize = true;
            lblIndex.Location = new Point(113, 400);
            lblIndex.Name = "lblIndex";
            lblIndex.Size = new Size(45, 20);
            lblIndex.TabIndex = 7;
            lblIndex.Text = "Índex";
            // 
            // txtBoxIndexMassa
            // 
            txtBoxIndexMassa.Location = new Point(250, 400);
            txtBoxIndexMassa.Name = "txtBoxIndexMassa";
            txtBoxIndexMassa.Size = new Size(125, 27);
            txtBoxIndexMassa.TabIndex = 8;
            // 
            // lblEstat
            // 
            lblEstat.AutoSize = true;
            lblEstat.Location = new Point(188, 455);
            lblEstat.Name = "lblEstat";
            lblEstat.Size = new Size(0, 20);
            lblEstat.TabIndex = 9;
            // 
            // lblEstatFinal
            // 
            lblEstatFinal.AutoSize = true;
            lblEstatFinal.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblEstatFinal.Location = new Point(212, 455);
            lblEstatFinal.Name = "lblEstatFinal";
            lblEstatFinal.Size = new Size(0, 41);
            lblEstatFinal.TabIndex = 10;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            ClientSize = new Size(683, 538);
            Controls.Add(lblEstatFinal);
            Controls.Add(lblEstat);
            Controls.Add(txtBoxIndexMassa);
            Controls.Add(lblIndex);
            Controls.Add(btnNetejar);
            Controls.Add(btnCalcular);
            Controls.Add(txtBoxM);
            Controls.Add(lblIntroAlçada);
            Controls.Add(txtBoxKg);
            Controls.Add(lblIntroPes);
            Controls.Add(pictureBox1);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterParent;
            Text = "Calculadora d'index de massa corporal";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label lblIntroPes;
        private TextBox txtBoxKg;
        private Label lblIntroAlçada;
        private TextBox txtBoxM;
        private Button btnCalcular;
        private Button btnNetejar;
        private Label lblIndex;
        private TextBox txtBoxIndexMassa;
        private Label lblEstat;
        private Label lblEstatFinal;
    }
}
