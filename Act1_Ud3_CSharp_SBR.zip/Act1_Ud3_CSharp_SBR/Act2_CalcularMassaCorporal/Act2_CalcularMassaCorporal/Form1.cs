// Librer�as necesarias para:
// - CultureInfo / NumberStyles (convertir texto a n�mero con control de formato)
using System.Globalization;

// Librer�as base de C#
using System;

// Para usar Color, Font, SystemColors, etc.
using System.Drawing;

// Para trabajar con Windows Forms (Form, MessageBox, TextBox, Label, Button...)
using System.Windows.Forms;

namespace Act2_CalcularMassaCorporal
{
    // "partial" significa que esta clase est� dividida en dos archivos:
    // - Form1.cs (este archivo: l�gica)
    // - Form1.Designer.cs (creaci�n de controles: txtBoxKg, txtBoxM, lblEstatFinal, etc.)
    public partial class Form1 : Form
    {
        // Constructor: se ejecuta cuando se crea el formulario
        public Form1()
        {
            InitializeComponent(); // Inicializa y coloca todos los controles del dise�ador
        }

        // Evento Click del bot�n "Calcular"
        // Se ejecuta cuando el usuario pulsa el bot�n
        private void btnCalcular_Click(object sender, EventArgs e)
        {
            // 1) Leemos el texto de los TextBox y quitamos espacios (" 70 " -> "70")
            string txtKg = txtBoxKg.Text.Trim();  // Texto del peso
            string txtM = txtBoxM.Text.Trim();   // Texto de la altura

            // 2) Validaci�n: si alguno est� vac�o, mostramos error y salimos del m�todo
            if (string.IsNullOrEmpty(txtKg) || string.IsNullOrEmpty(txtM))
            {
                MessageBox.Show("Pes i altura no poden estar buids.", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // No seguimos con el c�lculo si faltan datos
            }

            // 3) Convertimos el peso (texto) a n�mero double de forma segura
            // Si falla el parseo, mostramos error y dejamos al usuario corregirlo
            if (!TryParseDoubleFlexible(txtKg, out double pes))
            {
                MessageBox.Show("El pes ha de ser un n�m v�lid (per exemple 70,5).", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                // Selecciona el texto y vuelve el cursor al TextBox para que lo reescriba r�pido
                txtBoxKg.SelectAll();
                txtBoxKg.Focus();
                return;
            }

            // 4) Convertimos la altura (texto) a double de forma segura
            if (!TryParseDoubleFlexible(txtM, out double altura))
            {
                MessageBox.Show("La altura ha de ser un n�m v�lid (per exemple 1,83).", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

                txtBoxM.SelectAll();
                txtBoxM.Focus();
                return;
            }

            // 5) Validaci�n: no permitimos n�meros negativos
            if (pes < 0 || altura < 0)
            {
                MessageBox.Show("Pes i altura no poden ser negatius", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 6) Validaci�n: la altura no puede ser 0 (evita divisi�n entre 0)
            if (altura == 0)
            {
                MessageBox.Show("L'altura no pot ser '0'", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 7) Calculamos el IMC:
            // F�rmula: IMC = peso / (altura^2)
            double imc = pes / (altura * altura);

            // 8) Mostramos un mensaje seg�n el resultado del IMC
            // (Aqu� tu regla es: si IMC > 30, mensaje rojo; si no, mensaje verde)
            if (imc > 30)
            {
                lblEstatFinal.Text = "Has de cuidar-te";
                lblEstatFinal.ForeColor = Color.Red;
            }
            else
            {
                lblEstatFinal.Text = "Est�s en forma";
                lblEstatFinal.ForeColor = Color.Green;
            }

            // 9) Mostramos el IMC en el TextBox del �ndice.
            // ToString("0.00") muestra siempre 2 decimales.
            // Ejemplos:
            //  3.5   -> "03.50"
            //  23.12 -> "23.12
            // Cambiamos imc (double) a string
            txtBoxIndexMassa.Text = imc.ToString("0.00");
        }

        // Evento Click del bot�n "Netejar" (Limpiar)
        private void btnNetejar_Click(object sender, EventArgs e)
        {
            // 1) Limpiamos los campos de entrada
            txtBoxKg.Text = "";
            txtBoxM.Text = "";

            // 2) Limpiamos el label de estado y lo devolvemos al color por defecto
            lblEstat.Text = "";
            lblEstat.ForeColor = SystemColors.ControlText;

            // 3) Devolvemos el cursor al primer TextBox para que el usuario empiece de nuevo
            txtBoxKg.Focus();
        }

        // Funci�n auxiliar: intenta convertir un texto a double aceptando coma o punto.
        // Devuelve true si pudo convertir, false si no.
        private bool TryParseDoubleFlexible(string input, out double value)
        {
            // Cambiamos coma por punto para poder parsear con InvariantCulture
            // Ej: "70,5" -> "70.5"
            string normalizado = input.Replace(',', '.');

            // InvariantCulture usa punto como separador decimal.
            // NumberStyles.Float permite decimales, signo, etc.
            return double.TryParse(normalizado, NumberStyles.Float, CultureInfo.InvariantCulture, out value);
        }
    }
}
